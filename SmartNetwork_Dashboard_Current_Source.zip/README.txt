SMART NETWORK — CONNECTIVITY & STORAGE DIAGNOSTIC DASHBOARD
Version 1.1

START
cd "/Users/x/Documents/SmartNetwork/Dashboard_UI"
python3 smart_network_dashboard.py

FEATURES
- Live macOS network and storage discovery
- Wi-Fi and Ethernet diagnostics
- Windows FTP and SMB connectivity checks
- Dynamic summary KPI cards
- Animated glowing Smart Network logo
- Live Toronto and Dhaka clocks
- Current weather for Toronto and Dhaka (Open-Meteo)
- Dashboard screenshot capture

SCREENSHOTS
Saved in the Screenshots folder.

LOGS
Saved in the Logs folder.

SAFETY
Read-only diagnostics only. No drive files are uploaded, overwritten,
or deleted. No firewall, network, or share permissions are changed.
C/D/F/G Windows drive letters are not assumed to be share names.
